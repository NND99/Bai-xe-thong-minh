B1: Copy dữ liệu và chạy trên SQL.
B2: Chạy Parking.sln vào DBConnect trong lớp DAO sửa lại Data Source(ServerName SQL của bạn), Pwd của SQL(nếu có).
B3: Vào MagtekCardReader_Parking chạy MagtekCardReader.sln 
B4: Vào tải hình ảnh phù hợp với id thẻ tag bạn sử dụng.
